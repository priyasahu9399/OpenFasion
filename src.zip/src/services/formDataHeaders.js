export const formDataHeaders = {
    headers: {
        "Content-Type": "multipart/form-data",
        "Content-Disposition": "form-data",
    }
}