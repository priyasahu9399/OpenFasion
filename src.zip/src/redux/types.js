export const LOADING = 'LOADING';
export const ONBOARDING = 'ONBOARDING';
export const AUTH_TOKEN = 'AUTH_TOKEN';
// export const GET_USER = 'GET_USER';

// export const HOME_DATA = 'HOME_DATA';

// export const GET_ALLBLOG = 'GET_ALLBLOG'; //home page
// export const GET_BLOG_BYID = 'GET_BLOG_BYID'; //home page

// export const GET_ADDRESS_BYUSERID = 'GET_ADDRESS_BYUSERID';
// export const GET_ADDRESS_BYID = 'GET_ADDRESS_BYID';
// export const GET_PINCODE = 'GET_PINCODE';

// export const GET_CARTS_BYUSERID = 'GET_CARTS_BYUSERID';
// export const GET_CART_BY_USERID_Of_BUYNOW = 'GET_CART_BY_USERID_Of_BUYNOW';
// export const DUMMY_ADD_CART_DATA = 'DUMMY_ADD_CART_DATA';

// export const GET_ALL_PRODUCT = 'GET_ALL_PRODUCT';
// export const GET_PRODUCT_BYID = 'GET_PRODUCT_BYID';
// export const GET_RELATIVE_PRODUCT = 'GET_RELATIVE_PRODUCT';
// export const GET_ALTERNATIVE_PRODUCT = 'GET_ALTERNATIVE_PRODUCT';

// export const ALLPRODUCT_FILTER = 'ALLPRODUCT_FILTER';

// export const GET_FILTER = 'GET_FILTER';

// export const GET_SINGLE_REVIEW = 'GET_SINGLE_REVIEW';

// export const GET_ORDER_BYID = 'GET_ORDER_BYID';
// export const GET_ORDER_BY_USERID = 'GET_ORDER_BY_USERID';

// export const GET_WISHLIST_BYID = 'GET_WISHLIST_BYID';
// export const GET_WISHLIST_BY_USERID = 'GET_WISHLIST_BY_USERID';

// export const GET_COMPANY = 'GET_COMPANY'; //home page
// export const GET_COUPON = 'GET_COUPON';

// export const GET_CATEGORY = 'GET_CATEGORY';
// export const NEW_ARRIVAL = 'NEW_ARRIVAL';
// export const FIFTY_PERCENT_OFF = 'FIFTY_PERCENT_OFF';
// export const GET_ALLBRAND = 'GET_ALLBRAND';
// export const GET_TESTIMONIAL = 'GET_TESTIMONIAL';
// export const GET_NOTIFICATION_USERID = 'GET_NOTIFICATION_USERID';
// export const GET_SEENCOUNT = 'GET_SEENCOUNT';
// export const GET_ALL_AFFILIATE = 'GET_ALL_AFFILIATE';
// export const GET_CONTACT_BYID = 'GET_CONTACT_BYID';
