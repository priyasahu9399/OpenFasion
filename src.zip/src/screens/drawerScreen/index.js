import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import Collapsible from 'react-native-collapsible';
import {COLORS, FONTS, images, icons, data} from '../../constants';
import styles from './styles';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import BorderHeading from "./../../component/carts/borderHeading";

const {height, width} = Dimensions.get('window');

const DrawerList = ({
  icon,
  title,
  subtitle1,
  subtitle2,
  subtitle3,
  subtitle4,
  subtitle5,
  subtitle6,
  subtitle7,
  subtitle8,
  subtitle9,
  term,
  icon1,
  icon2,
  icon3,
  icon4,
  icon5,
  icon6,
  icon7,
  icon8,
  iconstyle,
}) => {
  const [isCollapsed, setCollapsed] = useState(true);
  return (
    <>
      <TouchableOpacity
        onPress={() => setCollapsed(!isCollapsed)}
        style={styles.collapsbox}>
        <Text style={styles.collapstitle}>{title}</Text>
        <SimpleLineIcons
          name={!isCollapsed == true ? 'arrow-up' : 'arrow-down'}
          size={15}
          color={COLORS.gray}
        />
      </TouchableOpacity>

      <Collapsible collapsed={isCollapsed}>
        <View style={styles.subtitlebox}>
          {subtitle1 && (
            <TouchableOpacity>
              <Text style={styles.collapsubtitle}>{subtitle1}</Text>
            </TouchableOpacity>
          )}
          {subtitle2 && (
            <TouchableOpacity>
              <Text style={styles.collapsubtitle}>{subtitle2}</Text>
            </TouchableOpacity>
          )}
          {subtitle3 && (
            <TouchableOpacity>
              <Text style={styles.collapsubtitle}>{subtitle3}</Text>
            </TouchableOpacity>
          )}
          {subtitle4 && (
            <TouchableOpacity>
              <Text style={styles.collapsubtitle}>{subtitle4}</Text>
            </TouchableOpacity>
          )}
          {subtitle5 && (
            <TouchableOpacity>
              <Text style={styles.collapsubtitle}>{subtitle5}</Text>
            </TouchableOpacity>
          )}
        </View>
      </Collapsible>
    </>
  );
};

const DrawerScreen = ({navigation}) => {
  const [borderActive, setBorderActive] = useState(1);
  return (
    <ScrollView showsVerticalScrollIndicator={false}>
      <TouchableOpacity onPress={() => navigation?.closeDrawer()}>
        <Image source={icons.Close} style={styles.cross} />
      </TouchableOpacity>
      <View>
        <View style={styles.row}>
          <TouchableOpacity
            onPress={() => setBorderActive(1)}
            style={styles.categorybox}>
            <Text
              style={[
                styles.categorytext,
                borderActive == 1 && {color: COLORS.black},
              ]}>
              WOMEN
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setBorderActive(2)}
            style={styles.categorybox}>
            <Text
              style={[
                styles.categorytext,
                borderActive == 2 && {color: COLORS.black},
              ]}>
              MAN
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setBorderActive(3)}
            style={styles.categorybox}>
            <Text
              style={[
                styles.categorytext,
                borderActive == 3 && {color: COLORS.black},
              ]}>
              KIDS
            </Text>
          </TouchableOpacity>
        </View>

        <View>
          {(borderActive == 1 || borderActive == 2 || borderActive == 3) && (
            <Image
              source={icons.border2}
              style={[
                styles.border,
                borderActive == 2 && {left: width * 0.22},
                borderActive == 3 && {left: width * 0.45},
              ]}
            />
          )}
        </View>
      </View>

      <DrawerList
        icon={icons.hair}
        title="New"
        subtitle1="Sampoo"
        subtitle2="Conditionar"
        subtitle3="Blouse"
        subtitle4="Shirt"
      />
      <DrawerList
        icon={icons.makeup}
        title="Apparel"
        subtitle1="Outer"
        subtitle2="Dress"
        subtitle3="Blouse"
        subtitle4="Shirt"
        subtitle5="Knitwear"
        subtitle6="T-Shirt"
      />
      <DrawerList
        icon={icons.face2}
        title="Bag"
        subtitle1="powder"
        subtitle2="kajal"
      />
      <DrawerList
        icon={icons.baby}
        title="Shoes"
        subtitle1="baby shop"
        subtitle2="baby loation"
        subtitle3="baby cream"
      />
      <DrawerList
        icon={icons.face}
        title="Beauty"
        subtitle1="face product"
        subtitle2="face wash"
        subtitle3="loation"
        subtitle4="cream"
      />
      <DrawerList
        icon={icons.blog}
        iconstyle={{width: width * 0.05}}
        title="Accessories"
        subtitle1="ALL Blog"
        subtitle2="Blog cart"
      />

      <View>
        <View
          style={[
            styles.row,
            {borderBottomWidth: 0, marginTop: height * 0.03},
          ]}>
          <Image source={icons.Call} style={styles.bottomicon} />
          <Text style={styles.bottomicontext}>(786) 713-8616</Text>
        </View>
        <View
          style={[
            styles.row,
            {borderBottomWidth: 0, marginVertical: height * 0.02},
          ]}>
          <Image source={icons.Location} style={styles.bottomicon} />
          <Text style={styles.bottomicontext}>Store locator</Text>
        </View>
      </View>

      <BorderHeading border boxstyle={{marginVertical: height * 0.02}} />
      <View style={styles.iconrow}>
        <TouchableOpacity>
          <Image source={icons.twit} style={styles.appicon} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image source={icons.insta2} style={styles.appicon} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image source={icons.yutube} style={styles.appicon} />
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};
export default DrawerScreen;
