import {StyleSheet, Dimensions} from 'react-native';
import {COLORS, FONTS} from '../../constants';
const {height, width} = Dimensions.get('window');
export default StyleSheet.create({
  container: {
    backgroundColor: COLORS.white,
    flex: 1,
  },
  innercontainer: {
    alignSelf: 'center',
    width: width * 0.94,
    backgroundColor: COLORS.white,
  },
  heading: {
    fontSize: width * 0.042,
    ...FONTS.fourHundred,
    color: COLORS.black,
    marginVertical: height * 0.01,
    letterSpacing: 3,
  },
  cross: {
    width: width * 0.06,
    height: width * 0.06,
    resizeMode: 'contain',
    tintColor: COLORS.black,
    marginTop: height * 0.05,
  },
  border: {
    borderBottomWidth: 1,
    borderColor: COLORS.gray1,
    marginTop: height * 0.1,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: height * 0.01,
  },
  subtotal: {
    ...FONTS.fourHundred,
    color: COLORS.black,
    fontSize: width * 0.036,
  },
  graytext: {
    ...FONTS.fourHundred,
    color: COLORS.gray,
    fontSize: width * 0.034,
    marginBottom: height * 0.02,
    
  },
 
});
