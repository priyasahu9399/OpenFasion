import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TouchableOpacity,
  StatusBar,
  ScrollView,
} from 'react-native';
import {COLORS, FONTS, images, icons, data} from '../../constants';
import styles from './styles';
import {connect} from 'react-redux';
import Loader from './../../component/modalLoading/index';
import BorderHeading from './../../component/carts/borderHeading';
import ButtonCustom from './../../component/Button/index';
import {Formik} from 'formik';
import * as yup from 'yup';
import InputBox from './../../component/InputText/index';

const {height, width} = Dimensions.get('window');

const AddAddress = ({navigation}) => {
  const [loading, setLoading] = useState(false);
  const AddressValidationSchema = yup.object().shape({
    firstname: yup.string().required('please enter first name'),
    lastname: yup.string().required('please enter last name'),
    address: yup.string().required('address is Required'),
    city: yup.string().required('please enter city'),
    state: yup.string().required('please enter state'),
    zipcode: yup.string().length(6).required('please enter zipcode'),
    mobile: yup
      .string()
      .min(10, ({min}) => `mobile number must be ${min} digit`)
      .required('mobile number is Required'),
  });

  return (
    <View style={styles.container}>
      <Loader loading={loading} />
      <StatusBar
        translucent
        backgroundColor="transparent"
        barStyle={'dark-content'}
      />
      <ScrollView
        style={styles.innercontainer}
        keyboardShouldPersistTaps={'handled'}
        showsVerticalScrollIndicator={false}>
        <BorderHeading
          heading="Add shipping adress"
          border
          boxstyle={{marginVertical: height * 0.014}}
        />
        <Formik
          validationSchema={AddressValidationSchema}
          initialValues={{
            firstname: '',
            lastname: '',
            address: '',
            city: '',
            state: '',
            zipcode: '',
            mobile: '',
          }}
          onSubmit={values => {
            console.log(values);
          }}>
          {({
            setFieldValue,
            handleChange,
            handleBlur,
            handleSubmit,
            touched,
            values,
            errors,
            isValid,
          }) => {
            return (
              <>
                <View style={styles.row}>
                  <InputBox
                    placeholder="First name"
                    onChangeText={handleChange('firstname')}
                    value={values?.firstname}
                    errors={touched?.firstname && errors?.firstname}
                    placeholderstyle={{width: width * 0.45}}
                    boxstyle={{width: width * 0.45}}
                  />

                  <InputBox
                    placeholder="Last name"
                    onChangeText={handleChange('lastname')}
                    value={values?.lastname}
                    errors={touched?.lastname && errors?.lastname}
                    placeholderstyle={{width: width * 0.45}}
                    boxstyle={{width: width * 0.45}}
                  />
                </View>
                <InputBox
                  placeholder="Address"
                  onChangeText={handleChange('address')}
                  value={values?.address}
                  errors={touched?.address && errors?.address}
                />
                <InputBox
                  value={values?.city}
                  placeholder="City"
                  onChangeText={handleChange('city')}
                  errors={touched?.city && errors?.city}
                />
                <View style={styles.row}>
                  <InputBox
                    value={values?.state}
                    placeholder="State"
                    onChangeText={handleChange('state')}
                    errors={touched?.state && errors?.state}
                    placeholderstyle={{width: width * 0.45}}
                    boxstyle={{width: width * 0.45}}
                  />

                  <InputBox
                    value={values?.zipcode}
                    placeholder="ZIP code"
                    onChangeText={handleChange('zipcode')}
                    errors={touched?.zipcode && errors?.zipcode}
                    placeholderstyle={{width: width * 0.45}}
                    boxstyle={{width: width * 0.45}}
                  />
                </View>
                <InputBox
                  placeholder="Phone number"
                  keyboardType="numeric"
                  maxLength={10}
                  value={values?.mobile}
                  errors={touched?.mobile && errors?.mobile}
                  onChangeText={handleChange('mobile')}
                />

                {/* <ButtonCustom
                  children="Add now"
                  onPress={handleSubmit}
                  btnStyle={{
                    alignSelf: 'center',
                    // marginVertical: height * 0.001,
                    position: 'absolute',
                    bottom: 0,
                  }}
                /> */}
              </>
            );
          }}
        </Formik>
      </ScrollView>
      <ButtonCustom
        children="Add now"
        // onPress={handleSubmit}
        onPress={() => navigation.goBack()}
        btnStyle={{
          alignSelf: 'center',
          // marginVertical: height * 0.001,
          position: 'absolute',
          bottom: 0,
        }}
      />
    </View>
  );
};
const mapStateToProps = state => ({});
const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(AddAddress);
