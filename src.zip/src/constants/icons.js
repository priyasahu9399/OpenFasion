const bag = require('../assets/icons/bag.png');
const bookmark = require('../assets/icons/bookmark.png');
const border = require('../assets/icons/border.png');
const Call = require('../assets/icons/Call.png');
const car = require('../assets/icons/car.png');
const Close = require('../assets/icons/Close.png');
const delivery = require('../assets/icons/delivery.png');
const download = require('../assets/icons/download.png');
const dress = require('../assets/icons/dress.png');
const Filter = require('../assets/icons/Filter.png');
const Happy = require('../assets/icons/Happy.png');
const Heart = require('../assets/icons/Heart.png');

const sqrfill = require('../assets/icons/sqrfill.png');
const insta1 = require('../assets/icons/insta1.png');
const insta2 = require('../assets/icons/insta2.png');
const Listview = require('../assets/icons/Listview.png');
const Location = require('../assets/icons/Location.png');
const love = require('../assets/icons/love.png');
const MasterCard = require('../assets/icons/MasterCard.png');
const Menu = require('../assets/icons/Menu.png');
const pd1 = require('../assets/icons/pd1.png');
const pd2 = require('../assets/icons/pd2.png');
const pd3 = require('../assets/icons/pd3.png');
const pd4 = require('../assets/icons/pd4.png');
const Plus = require('../assets/icons/Plus.png');
const promocode = require('../assets/icons/promocode.png');
const rarrow = require('../assets/icons/rarrow.png');
const rarrow2 = require('../assets/icons/rarrow2.png');
const Refresh = require('../assets/icons/Refresh.png');
const sad = require('../assets/icons/sad.png');
const search = require('../assets/icons/search.png');
const sqr = require('../assets/icons/sqr.png');
const success = require('../assets/icons/success.png');
const Tag = require('../assets/icons/Tag.png');
const textus = require('../assets/icons/textus.png');
const Twitter = require('../assets/icons/Twitter.png');
const yutube = require('../assets/icons/yutube.png');
const zoom = require('../assets/icons/zoom.png');
const twit = require('../assets/icons/twit.png');
const larrow = require('../assets/icons/larrow.png');
const message = require('../assets/icons/message.png');
const border2 = require('../assets/icons/border2.png');
const October = require('../assets/icons/October.png');
const star = require('../assets/icons/star.png');



export default {
  bag,
  bookmark,
  border,
  Call,
  car,
  Close,
  delivery,
  download,
  dress,
  Filter,
  Happy,
  Heart,
  sqrfill,
  insta1,
  insta2,
  Listview,
  Location,
  love,
  pd1,
  pd2,
  pd3,
  pd4,
  Plus,
  promocode,
  rarrow,
  rarrow2,
  Refresh,
  sad,
  search,
  sqr,
  success,
  Tag,
  textus,
  Twitter,
  MasterCard,
  Menu,
  zoom,
  yutube,
  twit,
  larrow,
  message,
  border2,
  October,
  star,
};
