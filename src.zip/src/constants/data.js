import icons from './icons';
import images from './images';
import {COLORS} from './theme';

const categorylist = [
  {id: 1, text: 'Fashion'},
  {id: 2, text: 'Promo'},
  {id: 3, text: 'Policy'},
  {id: 4, text: 'Lookbook'},
  {id: 5, text: 'Sale'},
];

const homesliderlist = [
  {id: 0, image: images.home1},
  {id: 1, image: images.home2},
  {id: 2, image: images.home3},
];

const newarrival = [
  {id: 1, text: 'All'},
  {id: 2, text: 'Apparel'},
  {id: 3, text: 'Dress'},
  {id: 4, text: 'Tshirt'},
  {id: 5, text: 'Bag'},
];

const NewArrivallist = [
  {
    id: 0,
    img: images.home2,
    title: '21WN reversible angora cardigan',
    price: '120',
  },
  {
    id: 1,
    img: images.home3,
    title: '21WN reversible angora cardigan',
    price: '220',
  },
  {
    id: 2,
    img: images.home4,
    title: '21WN reversible angora cardigan',
    price: '125',
  },
  {
    id: 3,
    img: images.home5,
    title: 'Oblong bag',
    price: '120',
  },
];

const brand = [
  {id: 0, image: images.brand1},
  {id: 1, image: images.brand2},
  {id: 2, image: images.brand3},
  {id: 3, image: images.brand4},
  {id: 4, image: images.brand5},
  {id: 5, image: images.brand6},
];

const tranding = [
  {id: 1, text: '#2021'},
  {id: 2, text: '#spring'},
  {id: 3, text: '#collection'},
  {id: 4, text: '#fall'},
  {id: 5, text: '#dress'},
  {id: 6, text: '#autumncollection'},
  {id: 7, text: '#openfashion'},
  {id: 8, text: '#dress'},
];

const followus = [
  {
    id: 0,
    title: '@mia',
    img: images.black1,
  },
  {
    id: 1,
    title: '@_jihyn',
    img: images.black2,
  },
  {
    id: 2,
    title: '@mia',
    img: images.black3,
  },
  {
    id: 3,
    title: '@_jihyn',
    img: images.black4,
  },
];

const bloglist = [
  {
    id: 0,
    title: '2021 Style Guide: The Biggest Fall Trends',
    img: images.home5,
    day: '4 days ago',
    list: [
      {id: 1, text: '#Fashion'},
      {id: 2, text: '#Tip'},
    ],
  },
  {
    id: 1,
    title: '2021 Style Guide: The Biggest Fall Trends',
    img: images.home6,
    day: '5 days ago',

    list: [
      {id: 1, text: '#Fashion'},
      {id: 2, text: '#Tip'},
    ],
  },
  {
    id: 2,
    title: '2021 Style Guide: The Biggest Fall Trends',
    img: images.black3,
    day: '4 days ago',

    list: [
      {id: 1, text: '#Fashion'},
      {id: 2, text: '#Tip'},
    ],
  },
  {
    id: 3,
    title: '2021 Style Guide: The Biggest Fall Trends',
    img: images.skin1,
    day: '4 days ago',

    list: [
      {id: 1, text: '#Fashion'},
      {id: 2, text: '#Tip'},
    ],
  },
  {
    id: 4,
    title: '2021 Style Guide: The Biggest Fall Trends',
    img: images.black1,
    day: '4 days ago',

    list: [
      {id: 1, text: '#Fashion'},
      {id: 2, text: '#Tip'},
    ],
  },
];

const bloglistviewtype = [
  {
    id: 0,
    img: images.cloth2,
    title: '2021 Style Guide: The Biggest Fall Trends',
    subtitle:
      'The excitement of fall fashion is here and I’m already loving some of the trend forecasts ',
    day: '5 days ago',
  },
  {
    id: 1,
    img: images.home3,
    title: '3 Pairs of Denim You Won’t Believe',
    subtitle:
      'The excitement of fall fashion is here and I’m already loving some of the trend forecasts ',

    day: '6 days ago',
  },
  {
    id: 2,
    img: images.home4,
    title: '5 Fall Looks I’m Loving',
    subtitle:
      'The excitement of fall fashion is here and I’m already loving some of the trend forecasts ',

    day: '01/11/2021',
  },
  {
    id: 3,
    img: images.black2,
    title: '5 Fall Boot Trends You Need to Try',
    subtitle:
      'The excitement of fall fashion is here and I’m already loving some of the trend forecasts ',

    day: '01/11/2021',
  },
  {
    id: 3,
    img: images.cloth2,
    title: 'Style Guide: The Biggest Fall Trends',
    subtitle:
      'The excitement of fall fashion is here and I’m already loving some of the trend forecasts ',

    day: '01/11/2021',
  },
];

const hashlist = [
  {
    id: 0,
    text: '#Fashion',
  },
  {
    id: 1,
    text: '#Tips',
  },
];

const searchlist = [
  {
    id: 0,
    text: 'Dress',
  },
  {
    id: 1,
    text: 'Collection',
  },
  {
    id: 2,
    text: 'Nike',
  },
];

const searchlist1 = [
  {
    text: 'Trend',
  },
  {
    text: 'Dress',
  },
  {
    text: 'Bag',
  },
  {
    text: 'Tshirt',
  },
  {
    text: 'Beauty',
  },
  {
    text: 'Accessories',
  },
];

const categorygridlist = [
  {
    id: 0,
    img: images.cloth1,
    title: '21WN ',
    subtitle: 'reversible angora cardigan ',
    price: '120',
  },
  {
    id: 1,
    img: images.home3,
    title: '21WN ',
    subtitle: 'reversible angora cardigan ',
    price: '220',
  },
  {
    id: 2,
    img: images.cloth2,
    title: 'lamerei ',
    subtitle: 'reversible angora cardigan ',
    price: '125',
  },
  {
    id: 3,
    img: images.home5,
    title: 'Oblong bag',
    subtitle: 'reversible angora cardigan ',
    price: '120',
  },
  {
    id: 4,
    img: images.home2,
    title: '21WN ',
    subtitle: 'reversible angora cardigan ',
    price: '220',
  },
  {
    id: 5,
    img: images.home4,
    title: 'lamerei',
    subtitle: 'reversible angora cardigan ',
    price: '125',
  },
  {
    id: 6,
    img: images.cloth3,
    title: 'Oblong bag',
    subtitle: 'reversible angora cardigan ',
    price: '120',
  },
];

const categorygridlist1 = [
  {value: 0, label: 'Woman'},
  {value: 1, label: 'All apparel'},
  {value: 2, label: 'Man'},
];
const number = [
  {
    num: 1,
  },
  {
    num: 2,
  },
  {
    num: 3,
  },
  {
    num: 4,
  },
  {
    num: 5,
  },
];
const collection = [
  {
    id: 0,
    title: 'October collection',
    img: images.collaction1,
    num: '01',
  },
  {
    id: 1,
    title: 'Black collection',
    img: images.collaction2,
    num: '02',
  },
  {
    id: 2,
    title: 'HAE BY HAEKIM',
    img: images.black3,
    num: '03',
  },
  {
    id: 3,
    title: 'Yellow green collection',
    img: images.black1,
    num: '04',
  },
];
// ---------------------------------------

const categorylistview = [
  {
    id: 0,
    bigimg: images.cloth1,
    title: 'lamerei',
    rate: '4.9',
    subtitle: 'Recycle Boucle Knit Cardigan Pink',
    price: '120',
    sizes: [
      {id: 0, size: 'S'},
      {id: 1, size: 'M'},
      {id: 2, size: 'L'},
    ],
  },
  {
    id: 1,
    bigimg: images.cloth2,
    title: 'lamerei',
    rate: '4.9',
    subtitle: 'Recycle Boucle Knit Cardigan Pink',
    price: '120',
    sizes: [
      {id: 0, size: 'S'},
      {id: 1, size: 'M'},
      {id: 2, size: 'L'},
      
    ],
  },
  {
    id: 2,
    bigimg: images.cloth3,
    title: 'lamerei',
    rate: '4.9',
    subtitle: 'Recycle Boucle Knit Cardigan Pink',
    price: '120',
    sizes: [
      {id: 0, size: 'S'},
      {id: 1, size: 'M'},
      {id: 2, size: 'XL'},
    ],
  },
  {
    id: 3,
    bigimg: images.cloth4,
    title: 'lamerei',
    rate: '4.9',
    subtitle: 'Recycle Boucle Knit Cardigan Pink',
    price: '120',
    sizes: [
      {id: 0, size: 'S'},
      {id: 1, size: 'M'},
      {id: 2, size: 'XXL'},
    ],
  },
];
const ViewCourse = [
  {
    id: 0,
    bigimg: images.course1,
    title: 'Basics of mobile',
    time: '12h 40min ',
    lesson: '6',
    price: '32,000',
  },
  {
    id: 1,
    bigimg: images.course2,
    title: 'Hardware Repair',
    time: '12h 40min ',
    lesson: '6',
    price: '32,000',
  },
  {
    id: 2,
    bigimg: images.course3,
    title: 'Software Repair',
    time: '12h 40min ',
    lesson: '6',
    price: '32,000',
  },
  {
    id: 3,
    bigimg: images.course4,
    title: 'Advanced Troubleshooting',
    time: '12h 40min ',
    lesson: '6',
    price: '32,000',
  },
  {
    id: 4,
    bigimg: images.course1,
    title: 'Advanced Troubleshooting',
    time: '12h 40min ',
    lesson: '6',
    price: '32,000',
  },
];
const notification = [
  {
    seen: 'seen',
    time: '6h ago',
    text1: 'New Course Offerings!',
    text2:
      'We are thrilled to introduce new courses that cover the latest advancements in mobile technology. ',
  },
  {
    seen: 'seen',
    time: '8h ago',
    text1: 'Free Workshop',
    text2:
      "Join our free workshop  on    'Troubleshooting  Common  Mobile Issues '  this  Saturday       at      10  AM.",
  },

  {
    time: '1d ago',
    text1: 'Feedback & Suggestions',
    text2:
      'We value your feedback. If you have any suggestions or concerns, please feel free to reach out to our administrative team.  ',
  },

  {
    time: '2h ago',
    text1: 'Stay Connected',
    text2:
      'Keep following us on social media and our website for the latest updates, tips, and tricks related to mobile repairing.',
  },
];

const chat = [
  {
    id: 0,
    name: 'Hello! This is Shivali. How may I help you?',
    time: '5.28 PM',
    direction: 'left',
  },
  {
    id: 1,
    name: "Hello! I'm interested in mobile training courses. Can you tell me more about what your institute offers?",
    time: '5.29 PM',
    direction: 'right',
  },
  {
    id: 2,
    name: "Hi there! Of course, we'd be happy to help. Our institute offers a wide range of mobile training courses for both beginners and advanced learners. We cover various aspects of mobile technology, including app development, and mobile device management. What specific area are you interested in?",
    time: '5.31 PM',
    direction: 'left',
  },
  {
    id: 3,
    img: images.green,
    direction: 'right',
  },
];
const TransactionCartdata = [
  {
    id: 0,
    app: 'Wallet',
    refer: '20167253-23458796',
    transId: 21,
    Amount: '23,99.00',
    summary: 'Paid for order purchase',
    total: '2,399.00',
  },
  {
    id: 1,
    app: 'Google Pay',
    refer: '20167253-23458796',
    transId: 16,
    Amount: '23,99.00',
    summary: 'Paid for order purchase',
    total: '2,399.00',
  },
  {
    id: 2,
    app: 'Wallet',
    refer: '20167253-23458796',
    transId: 19,
    Amount: '23,99.00',
    summary: 'Paid for order purchase',
    total: '2,399.00',
  },
  {
    id: 3,
    app: 'Google Pay',
    refer: '20167253-23458796',
    transId: 18,
    Amount: '23,99.00',
    summary: 'Paid for order purchase',
    total: '2,399.00',
  },
];

const courseVideo = [
  {
    id: 0,
    title: 'Introduction',
    time: '4min 12sec',
  },
  {
    id: 1,
    title: 'Introduction',
    time: '4min 12sec',
  },
  {
    id: 2,
    title: 'Introduction',
    time: '4min 12sec',
  },
  {
    id: 3,
    title: 'Introduction',
    time: '4min 12sec',
  },
  {
    id: 4,
    title: 'Introduction',
    time: '4min 12sec',
  },
];

const courseBuy = [
  {
    id: 0,
    title: 'Hardware Repair Course',
    date: 'Valid till Dec,2023',
    time: '2 Months',
    img: images.course2,
  },
];

const communitylist = [
  {
    id: 0,
    img: images.person1,
    title: 'Arvind Singh',
    subtitle: 'Unlock a whole new learning experience...',
  },
  {
    id: 0,
    img: images.person2,
    title: 'Ramesh Singh',
    subtitle: 'Hello Everyone, In Today’s class....',
  },
  {
    id: 0,
    img: images.person1,
    title: 'Ankit Singh',
    subtitle: 'Unlock a whole new learning experience...',
  },
  {
    id: 0,
    img: images.person2,
    title: 'Jay Kumar',
    subtitle: 'Hello Everyone, In Today’s class....',
  },
];

const communitydetaillist = [
  {
    id: 0,
    name: 'Arvind Singh',
    dsc: ' Hello Learners, Good Morning ! Today we will learn some basic tricks to rectify the problem.',
    link: 'https://mooxy.com/class/basics of mobile-part-1',
    like: 1,
    comment: 0,
    view: 56,
    time: '9:15 AM',
    day: 'Yesterday',
    img: images.person1,
  },
  {
    id: 1,
    name: 'Arvind Singh',
    dsc: ' Hello Learners, Good Morning ! Today we will learn some basic tricks to rectify the problem.',
    link: 'https://mooxy.com/class/basics of mobile-part-1',
    like: 2,
    comment: 2,
    view: 56,
    time: '9:15 AM',
    day: 'Today',
    img: images.person2,
  },
];

const notesinstitute = [
  {id: 0, title: 'Hardware Repair'},
  {id: 1, title: 'Basic Of Mobile'},
  {id: 2, title: 'Software Repair'},
  {id: 3, title: 'Basic and Advanced Troubleshooting'},
  {id: 4, title: 'Additional Learning'},
];
const practice = [
  {id: 0, title: '1. Study of Digital Electronics.', que: '10 Questions'},
  {id: 1, title: '2. Basics of mobile communication.', que: '10 Questions'},
  {
    id: 2,
    title:
      '3. Assembling and disassembling of various models of mobile phones.',
    que: '10 Questions',
  },
  {
    id: 3,
    title:
      '4. Study of various tools and equipment used in mobile phone repairs.',
    que: '10 Questions',
  },
  {
    id: 4,
    title: '5. Study of parts inside a mobile phone.',
    que: '10 Questions',
  },
  {id: 5, title: '6. Use of multimeter.', que: '10 Questions'},
];

const practiceque = [
  {
    que: '1. What is the fundamental difference between analog and digital electronics?',
    ans: ' Analog electronics deals with continuous signals, while digital electronics deals with discrete signals represented as 0s and 1s.',
  },
  {
    que: '2. What is a logic gate?',
    ans: 'A logic gate is an elementary building block of digital circuits. It processes binary information and produces an output based on logical operations (AND, OR, NOT, etc.).',
  },
  {
    que: '3. What is the significance of binary code in digital electronics?',
    ans: 'Binary code is the fundamental language used in digital electronics. It represents data and instructions in the form of 0s and 1s, making it easy for electronic devices to process and manipulate information.',
  },
  {
    que: '4. How does a digital-to-analog converter (DAC) differ from an analog-to-digital converter (ADC)?',
    ans: ' Analog electronics deals with continuous signals, while digital electronics deals with discrete signals represented as 0s and 1s.',
  },
  {
    que: '5. What is the fundamental difference between analog and digital electronics?',
    ans: ' Analog electronics deals with continuous signals, while digital electronics deals with discrete signals represented as 0s and 1s.',
  },
  {
    que: '6. What is the fundamental difference between analog and digital electronics?',
    ans: ' Analog electronics deals with continuous signals, while digital electronics deals with discrete signals represented as 0s and 1s.',
  },
  {
    que: '7. What is the fundamental difference between analog and digital electronics?',
    ans: ' Analog electronics deals with continuous signals, while digital electronics deals with discrete signals represented as 0s and 1s.',
  },
  {
    que: '8. What is the fundamental difference between analog and digital electronics?',
    ans: ' Analog electronics deals with continuous signals, while digital electronics deals with discrete signals represented as 0s and 1s.',
  },
];

const quiztopic = [
  {
    id: 0,
    title: 'Basics of mobile',
  },
  {
    id: 1,
    title: 'Hardware Repair',
  },
  {
    id: 2,
    title: 'Software Repair',
  },
  {
    id: 3,
    title: 'Basic and Advanced Troubleshooting',
  },
  {
    id: 4,
    title: 'Additional Learning',
  },
];

export default {
  categorylist,
  newarrival,
  NewArrivallist,
  homesliderlist,
  brand,
  tranding,
  followus,
  bloglist,
  bloglistviewtype,
  hashlist,
  categorygridlist,
  categorygridlist1,
  number,
  searchlist,
  searchlist1,
  collection,
  // -------------------
  categorylistview,
  ViewCourse,
  courseVideo,
  courseBuy,
  communitylist,
  communitydetaillist,
  notesinstitute,
  practice,
  practiceque,
  quiztopic,
};
