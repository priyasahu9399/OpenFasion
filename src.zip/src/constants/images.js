const black1 = require('../assets/images/black1.png');
const black2 = require('../assets/images/black2.png');
const black3 = require('../assets/images/black3.png');
const black4 = require('../assets/images/black4.png');

const brand1 = require('../assets/images/brand1.png');
const brand2 = require('../assets/images/brand2.png');
const brand3 = require('../assets/images/brand3.png');
const brand4 = require('../assets/images/brand4.png');
const brand5 = require('../assets/images/brand5.png');
const brand6 = require('../assets/images/brand6.png');

const cart = require('../assets/images/cart.png');

const cloth1 = require('../assets/images/cloth1.png');
const cloth2 = require('../assets/images/cloth2.png');
const cloth3 = require('../assets/images/cloth3.png');
const cloth4 = require('../assets/images/cloth4.png');
const cloth5 = require('../assets/images/cloth5.png');
const cloth6 = require('../assets/images/cloth6.png');

const collaction1 = require('../assets/images/collaction1.png');
const collaction2 = require('../assets/images/collaction2.png');
const collaction3 = require('../assets/images/collaction3.png');

const fourimg1 = require('../assets/images/fourimg1.png');
const fourimg2 = require('../assets/images/fourimg2.png');
const fourimg3 = require('../assets/images/fourimg3.png');
const fourimg4 = require('../assets/images/fourimg4.png');
const fourimg5 = require('../assets/images/fourimg5.png');

const home1 = require('../assets/images/home1.png');
const home2 = require('../assets/images/home2.png');
const home3 = require('../assets/images/home3.png');
const home4 = require('../assets/images/home4.png');
const home5 = require('../assets/images/home5.png');
const home6 = require('../assets/images/home6.png');
const home7 = require('../assets/images/home7.png');

const logo = require('../assets/images/logo.png');

const ring1 = require('../assets/images/ring1.png');
const ring2 = require('../assets/images/ring2.png');
const ring3 = require('../assets/images/ring3.png');
const ring4 = require('../assets/images/ring4.png');
const ring5 = require('../assets/images/ring5.png');
const ring6 = require('../assets/images/ring6.png');

const skin1 = require('../assets/images/skin1.png');
const skin2 = require('../assets/images/skin2.png');

const video = require('../assets/images/video.png');
export default {
  black1,
  black2,
  black3,
  black4,

  brand1,
  brand2,
  brand3,
  brand4,
  brand5,
  brand6,
  cart,

  cloth1,
  cloth2,
  cloth3,
  cloth4,
  cloth5,
  cloth6,
  collaction1,
  collaction2,
  collaction3,

  fourimg1,
  fourimg2,
  fourimg3,
  fourimg4,
  fourimg5,

  home1,
  home2,
  home3,
  home4,
  home5,
  home6,
  home7,
  logo,
  ring1,
  ring2,
  ring3,
  ring4,
  ring5,
  ring6,
  skin1,
  skin2,
  video,
};
